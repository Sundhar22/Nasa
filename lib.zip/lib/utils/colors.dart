import 'package:flutter/material.dart';

const Color kbackground = Color(0XFFFCFCFC);

const Color primarylight = Color(0xFFEDF6F3);

const Color primary = Color(0xFFDAEFE8);

const Color primarydark = Color(0xFF88A1AE);

const Color kaccent = Color(0xFF252435);

const Color kfont = Color(0xFF252435);

const Color kfontlight = Color(0xFFB4B7BF);
